$(document).ready(function () {
	home_slider();
	globalShowHide();
	CustomGropRadioSelect();
	popChkAllCheckbox();
	popChkAllCheckbox_inpage();
	DashboardleftPanelOpenClose();
	// tooltip
	$('[data-toggle="tooltip"]').tooltip(); 
	expandCollapsElementArea();
	
});

/*------------------------------------ home slider ---------------------------*/
function home_slider(){
$("#myCarousel").carousel({
         interval : 10000,
         pause: false
     });
}


/*-------------------------------- listing detail sidepanel horizontal scroll bar in mobile ----------------------------*/

function mobileGuestScroll(){
(function($){
  $(window).load(function(){
				
	$(".mobileGuestScroll").mCustomScrollbar({
		axis:"x",
		//theme:"3d",
		scrollInertia:550,
		scrollbarPosition:"outside"
	});
				
  });
})(jQuery);
}



/*----------------------------------- Homepage expand -----------------------------------------*/
function home_page_expand() {
    $("body").css({overflowY: 'scroll'});
    $(".homePlusButton").click(function () {
        var plusText = $(this).html();
        var $thistarget = $(this).attr('data-href');
        var offsetTop = $("#" + $thistarget).offset().top;
        if (plusText === "+") {
            $(this).html("-");
            $('html,body').animate({scrollTop: offsetTop}, 1500);
            $(".home_content_wrap").addClass("autoFlow");
        } else {
            $(this).html("+");
            $('html,body').animate({scrollTop: 0}, 600);
            setTimeout(function () {
                $(".home_content_wrap").removeClass("autoFlow");
            }, 600);
        }
    });
}

/*----------------------------------- Autoflow expand -----------------------------------------*/

function container_expand_height() {
    $(".expandButton").click(function () {
        $(this).closest('div.cntExpndFullArea').toggleClass("autoFlow");
        var Buttontext = $(this).text();
		//alert(Buttontext);
        if (Buttontext == "MORE +") {
            $(this).html("HIDE -");
        } else {
            $(this).html("MORE +");
        }
    });
}

/*--------------------------------------- more filter ---------------------------------------------
 more filter used in listing page.
 */
function more_filter() {
    $(".more_filter_button").click(function () {
        var buttonText = $(this).html();
        $(".more_filter_element_area").toggleClass("autoFlow");
        //$(".extra_fld_area").toggleClass("autoFlow");
        if (buttonText == "More +") {
            $(this).html("Hide -");
        } else {
            $(this).html("More +");
        }
    });
}

/*----------------------- listing detail right side sticky area popup open and closed for mobile --------------------------*/
function sticky_sidepanel_popup_for_mobile() {
    $(".button-visibility").click(function () {
        $(".listngDetlRgtPartOuter").toggleClass("show");
    });
}

/*----------------------- view more guest button --------------------------*/
function view_more_guest_button() {
    /*$(".vewMoreGustButton").click(function(){
     var ButtonText = $(this).html();
     $(".guestImgBlockArea").toggleClass("autoFlow");
     });*/
    $(".vewMoreGustButton").click(function () {
        var vwGuestBtn = $(this).html();
        $(".anonymous_guest").toggleClass("anonymous_guest_show");
        //alert(ButtonText);
        if (vwGuestBtn == "More +") {
            $(this).html("Hide -");
        } else {
            $(this).html("More +");
        }
        $(".guestImgBlockArea").toggleClass("autoFlow");
    });
}

/*------------------- lisitng page mapbox open close in search form ---------------------- */
function search_mapbox_expandCollaps() {
    $("#mapIconButton").click(function () {
        $(this).toggleClass("mapFilterIcon");
        $(".rgtFram_MapArea").toggleClass("mapExpand");
        $(".content_Right_flds_wrpr_Only").toggleClass("formView");
    });
}

/*----------------- listing page right and left panel expand and collaps --------------- */
function listing_page_resize() {
    $(".listing_collaps_button").click(function () {
        $("div#page_left_panel").toggleClass("resize");
        $("div#page_right_panel").toggleClass("slideright");
        setTimeout(function () {
            $(".content_Left_Frame .listing_collaps_button").toggleClass("visible_Button");
            $(".content_Right_Frame .listing_collaps_button").toggleClass("visible_Button");
            /*$('#page_left_panel').masonry({
             itemSelector: '.item',
             columnWidth: 120
             });*/
        }, 400);
    });
}

/*---------------- view more guest function ---------------------
 this is used in listing detail page for view all guest in sidepanel
 */
function viewmore_guest_sidebar() {
    $(".vewMoreGustButton").click(function () {
        $(".listngDetlSkyFormArea").toggleClass("listngDetlSkyHeight");
        $(".guestImgBlockArea").toggleClass("guestImgBlockAreaHide");
        $(".guestListArea").toggleClass("showFull");
    });
}

/*------------------------ datepicker -----------------------*/
/* date picker 
 website: https://eternicode.github.io/bootstrap-datepicker/?markup=input&format=&weekStart=&startDate=&endDate=&startView=0&minViewMode=0&maxViewMode=2&todayBtn=linked&clearBtn=false&language=en&orientation=bottom+auto&multidate=&multidateSeparator=&daysOfWeekDisabled=6&autoclose=on&todayHighlight=on&keyboardNavigation=on&forceParse=on#sandbox
 */
function bootstrap_datepicker() {
    $('.datepicker').datepicker({
        todayBtn: "linked",
        daysOfWeekDisabled: "6",
        autoclose: true,
        orientation: "bottom auto",
        todayHighlight: true
    });
}

/*--------------------- resposive tab -----------------------------*/
function responsive_horizon_tab() {
    $('.horizontalTab').easyResponsiveTabs({
        type: 'default', //Types: default, vertical, accordion           
        width: 'auto', //auto or any width like 600px
        fit: true, // 100% fit in a container
        closed: 'accordion', // Start closed if in accordion view
        activate: function (event) { // Callback function if tab is switched
            var $tab = $(this);
            var $info = $('#tabInfo');
            var $name = $('span', $info);
            $name.text($tab.text());
            $info.show();
        }
    });
}

/*---------------- event type checkbox for search panel ------------------------*/
function event_type_checkbox() {
    /* event type checkbox script on click */
    $(".eventTypeChkBox").click(function () {
        var $checks = $(this).find('input:checkbox[name=event_type]');
        var parent = $(this).html();
        $checks.prop("checked", !$checks.is(":checked"));
        if ($checks.is(":checked")) {
            $(this).addClass("selectBox");
        } else {
            $(this).removeClass("selectBox");
        }
    });
    /* closed */

    /* event type checkbox script for uncheck on load */
    $(window).load(function () {
        var checks = $(".eventTypeChkBox").find('input:checkbox[name=event_type]');
        checks.prop("checked", !checks.is(":checked"));
        if (checks.is(":checked")) {
            checks.prop("checked", !checks.is(":checked"))
        }
    });
}

/*------------------------ range_slider script -------------------------*/
function range_slider() {
    $(".ui-slider-handle:nth-child(2)").attr('data-index', 1);
    $(".ui-slider-handle:nth-child(3)").attr('data-index', 2);
    $(".slider")
            .slider({
                min: 0,
                max: 1000,
                range: true,
                values: [200, 800]
            })
            .slider("pips", {
                step: 100,
                rest: "label"
            })
            .slider("float");
    $(".ui-slider-handle").each(function () {
//                $(this).mouseup(function () {
        $(this).mouseup(function () {
            var dataIndex = $(this).attr('data-index');
            if (dataIndex === '1') {
                var $thisvaluemin = $(this).find('span.ui-slider-tip').html();
                $("#minvalue").attr('value', $thisvaluemin);
            }
            if (dataIndex === '2') {
                var $thisvaluemax = $(this).find('span.ui-slider-tip').html();
                $("#maxvalue").attr('value', $thisvaluemax);
            }
        });
    });
}

/* ===================================== Subhajit from here =================================
 * --------------------------- you add your codes above this line :) ------------------------*/
/* ================================= global sticky function ================================= */
function stikypanel() {
    var stickyContent = $(".sticky-box");
    var $stickTop = $(stickyContent).offset().top;
    var $stickLeft = $(stickyContent).offset().left;
    var fullContTop = $(".ui-full-width-content").offset().top;
//    var fullContHeight = $(".ui-full-width-content").innerHeight();
    var fullContHeight = $(".listDtlMapArea").innerHeight();
    //console.log('fullContHeight',fullContHeight);
    var actualFulltop = fullContTop - fullContHeight;
    $(window).scroll(function () {
        var wscrollTop = $(window).scrollTop();
        var thetop = wscrollTop - actualFulltop;
        $(stickyContent).each(function () {
            if (wscrollTop >= $stickTop) {
                $(this).addClass('is-stick');
                $(this).css({left: $stickLeft, marginTop: 0 + 'px'});
                $(this).find(".header-part").css({left: $stickLeft});
            } else {
                $(this).removeClass('is-stick');
                $(this).removeAttr('style');
                $(this).find(".header-part").css({left: 0});
            }
            if (wscrollTop >= actualFulltop-130) {//+300
//            if (wscrollTop >= fullContTop) {//+300
                $(this).css({top: -thetop-130});
            }
            else {
                $(this).css({top: 0});
            }
        });
    });

}

/* ================================== price details on mobile ============== */
function toggleRightPanel() {
    $(".toggle-slide").click(function () {
        $(this).closest(".sticky-box").toggleClass('slide-it-right');
    });
}

/* ====================== gallery ====================== */
function gallery() {
    $("[data-gallery]").click(function () {
        var $gtarget = $(this).attr('data-gallery');
        $("#"+$gtarget).css({height: '100%'});
    });
    $(".close-gallery-btn").click(function(){
       $(this).closest(".gallery-wrapper").css({height:'0'});
    });
    var $imgview = $(".image-view");
    var $imgcont = $(".gallery-lists");
    var $imglist = $($imgcont).children('li');
    var listWidth = $($imglist).outerWidth();

    var viewPortleft = $(".list-area").offset().left;
    // -- viewport left plus its widht to get the right edge / area ranges for right side
    var viewPortRight = $(".list-area").outerWidth() + viewPortleft; // ---------- right area end 
    var rightAreaStart = viewPortRight - listWidth; // --------------------------- right area start
    // -- area range for left side 
//    var leftareaEnd = viewPortleft + listWidth;
    $($imgcont).css({width: parseInt(listWidth * ($imglist.length)) + 'px'});
    // ---  maxRight is for latest negative left value of the carousal
    var maxRight = parseInt(listWidth * ($imglist.length)) - $(".list-area").outerWidth();
    var movevalue = listWidth * 3;
    // -------------- call image active function --------
    activeView();
    // --------- click and show on container -------------
    $($imglist).on('click', function () {
        // the active class 
        $($imglist).removeClass('active');
        $(this).addClass('active');
        activeView();
        carousalMove(this);
    });
    // ---------------- next / prev navs ---------
    $(".navslide").on('click', function () {
        var $datanav = $(this).attr("data-navslide");
        if ($datanav === "next-image") {
            var findActiveN = $($imgcont).find('li.active');
            var nextActive = $(findActiveN).next('li');
            if (nextActive.length !== 0) {
                $(findActiveN).removeClass("active");
                $(findActiveN).next('li').addClass("active");
                activeView();
                carousalMove(nextActive);
            }
        } else if ($datanav === "prev-image") {
            var findActiveP = $($imgcont).find('li.active');
            var prevActive = $(findActiveP).prev('li');
            if (prevActive.length !== 0) {
                $(findActiveP).removeClass("active");
                $(findActiveP).prev('li').addClass("active");
                activeView();
                carousalMove(prevActive);
            }
        }
    });
// --------------- image on view port --------------    
    function activeView() {
        var $thisimg = $($imgcont).find('li.active').find('img').attr('src');//var $thisimg = $(this).find('img').attr('src'); 
        var $thistitle = $($imgcont).find('li.active').attr('title');
        var $thisIndex = $($imgcont).find('li.active').index() + 1;
        $($imgview).css({backgroundImage: "url(" + $thisimg + ")"});
        $(".title-number").html($thisIndex + '/' + $imglist.length + ' ' + $thistitle);
    }
// ------------------ carousal movement function ------------ 
    function carousalMove(elem) {
        var $nleftValue = Math.abs(parseInt($($imgcont).css('left'))) + movevalue;
        var $pleftValue = parseInt($($imgcont).css('left')) + movevalue;
        var $thisLeft = $(elem).offset().left;
        var $thisRight = ($(elem).offset().left - $(elem).closest(".list-area").offset().left) + listWidth;
        if ($thisLeft >= rightAreaStart && $thisLeft <= viewPortRight) {
            $($imgcont).css({left: '-=' + movevalue + 'px'});
            if ($nleftValue >= maxRight) {
                $($imgcont).css({left: -maxRight + 'px'});
            }
        }
        if ($thisRight > 0 && $thisRight <= listWidth) {
            $($imgcont).css({left: '+=' + movevalue + 'px'});
            if ($pleftValue > 0) {
                $($imgcont).css({left: 0 + 'px'});
            }
        }
    }
}

/* ================================== global show / hide with data attribute ======================= */
function globalShowHide(){
	$("[data-viewtarget]").on('click', function(){
		var $gettarget = $(this).attr('data-viewtarget');
		$("[data-targetview='"+$gettarget+"']").toggleClass('viewactive');
	});
}

/*================================ custom scrollbar for Form page left panel ==================================*/
function LeftPanelCustomScroll(){
	(function($){
	  $(window).load(function(){
		  $("#leftPanelScrollArea").mCustomScrollbar({ theme:"minimal",alwaysShowScrollbar:1 });
	  });
  })(jQuery);
}

function MidPanelCustomScroll(){
	(function($){
	  $(window).load(function(){
		  $("#MidPanelScrollArea").mCustomScrollbar({ theme:"minimal"});
	  });
  })(jQuery);
}

/*================================= custom radio button ===================================*/
function CustomGropRadioSelect(){
	$('.custom_radio_li').click(function() {
		$('.custom_radio_li').removeClass("active_radio_li");
    $(this).find('input:radio')[0].checked = true;    
	$(this).toggleClass('active_radio_li');
});
}
/*================================= expandCollapsElement ===================================*/
function expandCollapsElementArea(){
$('.expandCollapsBtn').click(function() {
    var expandCollapsElement = $(this).attr('data-my-element');
	var expandCollapsElementText = $(this).html();
		if(expandCollapsElementText=="MORE +"){
			$(this).html("HIDE -");
		}else if(expandCollapsElementText=="HIDE -"){
			$(this).html("MORE +");
		}else if(expandCollapsElementText=="+"){
			$(this).html("-");
		}else if(expandCollapsElementText=="-"){
			$(this).html("+");
		}
    $('.expandCollapsArea[data-my-element = '+expandCollapsElement+']').toggleClass('autoFlow');
});	
}

/*============================= check all checkbox in popup =====================================*/
function popChkAllCheckbox(){
$('.checkAll').click(function() {
	$("input:checkbox").prop('checked', $(this).prop("checked"));
});	
}

/*================== check full column checkbox in notification page =======================*/
function popChkAllCheckbox_inpage(){
$('.check_Column_1_All').click(function() {
	$(".check_Column_1 input:checkbox").prop('checked', $(this).prop("checked"));
});	
$('.check_Column_2_All').click(function() {
	$(".check_Column_2 input:checkbox").prop('checked', $(this).prop("checked"));
});
$('.check_Column_3_All').click(function() {
	$(".check_Column_3 input:checkbox").prop('checked', $(this).prop("checked"));
});
}

/*========================== dashboard left panel open closed for mobile =========================*/
function DashboardleftPanelOpenClose(){
$(".left-statusbar-btn").click(function(){
	var btnTxt =$(this).html();
	if(btnTxt=='Navigation <i class="fa fa-angle-down"></i>'){
		$(this).html('Navigation <i class="fa fa-angle-up"></i>');	
	}else{
		$(this).html('Navigation <i class="fa fa-angle-down"></i>');
	}
	$("#leftPanelScrollArea").toggleClass("expand");
	$(".dashbrdLFTNavPanel").toggleClass("expand");	
});
}
/*========================== Switch Button =========================*/
$(document).ready(function(){	
	$('.switch').click(function() {
    $(this).find('.switchBtn').toggleClass('moveLeft moveRight');
}); 
});

