/* stcky right sidebar header */
;(function ( $, window, document, undefined ) {

	var pluginName = "sticky";
	var defaults = {
		stickyClass: 'sdui-sticky-content',
        anchorClass: 'sdui-sticky-content-anchor',
        activeClass: 'is-active'
	};

	function Plugin ( element, options ) {
		this.element = element;

		this.settings = $.extend( {}, defaults, options );
		this._defaults = defaults;
		this._name = pluginName;
		this.init();
	}

	Plugin.prototype = {
		init: function () {
			$(this.element).addClass(this.settings.stickyClass);

			this.elementWidth = $(this.element).width();
			this.elementHeight = $(this.element).outerHeight();
			this.elementAnchor = this.createAnchor();

			this.bindEvents();
		},

		bindEvents: function () {
			var self = this;

			$(window).scroll( function () {
				self.refreshPosition();
			});
		},

		createAnchor: function () {
			return $('<div>').addClass(this.settings.anchorClass).insertBefore(this.element);
		},

		refreshPosition: function () {
			var scrollTop = $(window).scrollTop(),
	            elementAnchorTop = this.elementAnchor.offset().top;

	        if (scrollTop > elementAnchorTop) {
	            this.fixElement()
	        } else {
	            this.releaseElement();
	        }
		},

		fixElement: function () {
			$(this.element).css({ 
            	position: 'fixed',
            	top: '0px',
            	'z-index': 1000,
            	'width': this.elementWidth
            }).addClass(this.settings.activeClass);

            $(this.elementAnchor).height(this.elementHeight);
		},

		releaseElement: function () {
			$(this.element).css({ 
            	position: 'relative',
            	top: ''
            }).removeClass(this.settings.activeClass);

            $(this.elementAnchor).height(0);
		}
	};

	$.fn[ pluginName ] = function ( options ) {
		return this.each(function() {
			if ( !$.data( this, "plugin_" + pluginName ) ) {
				$.data( this, "plugin_" + pluginName, new Plugin( this, options ) );
			}
		});
	};

})( jQuery, window, document );

$(document).ready(function() {
(function(){
                $('.stk').sticky({
                    stickyClass: 'sticky',
                    anchorClass: 'sticky-anchor'
                });
            }());
});


/* stiky right sidebar */
(function ( $ ) {
 
$.fn.stickySidebar = function( options ) {
 
var config = $.extend({
headerSelector: '.header_area',
innerBannerSelector: '#innrBannerArea',
contentSelector: '#listngDetlLftCntArea',
contentBottomSelector: '#listngDetlBtmCntArea',
footerSelector: '.footerFullArea',
sidebarTopMargin: 30,
footerThreshold: 100
}, options);
 
var fixSidebr = function() {
 
		var sidebarSelector = $(this);
		var viewportHeight = $(window).height();
		var viewportWidth = $(window).width();
		var documentHeight = $(document).height();
		var headerHeight = $(config.headerSelector).outerHeight();
		var innerbannerHeight = $(config.innerBannerSelector).outerHeight();
		var sidebarHeight = sidebarSelector.outerHeight();
		var contentHeight = $(config.contentSelector).outerHeight();
		var contentBottomHeight = $(config.contentBottomSelector).outerHeight();
		var footerHeight = $(config.footerSelector).outerHeight();
		var scroll_top = $(window).scrollTop();
		var fixPosition = contentHeight - sidebarHeight;
		var breakingPoint1 = headerHeight + innerbannerHeight;
		var breakingPoint2 = documentHeight - (sidebarHeight + contentBottomHeight + footerHeight + config.footerThreshold);
 
		// calculate
		if ( (contentHeight > sidebarHeight) && (viewportHeight > sidebarHeight) ) {
		 
				if (scroll_top < breakingPoint1) {
				 
				sidebarSelector.removeClass('sticky');
		 
		} else if ((scroll_top >= breakingPoint1) && (scroll_top < breakingPoint2)) {
		 
				sidebarSelector.addClass('sticky').css('top', config.sidebarTopMargin);
		 
		} else {
		 
		var negative = breakingPoint2 - scroll_top;
		sidebarSelector.addClass('sticky').css('top',negative);
		 
		}
 
	}
};
 
return this.each( function() {
	$(window).on('scroll', $.proxy(fixSidebr, this));
	$(window).on('resize', $.proxy(fixSidebr, this))
	$.proxy(fixSidebr, this)();
});
 
};
 
}( jQuery ));

$(document).ready(function() {
	
			$('#listngDetlRgtStkyCntArea').stickySidebar({
				sidebarTopMargin: 0,
				footerThreshold: 100
			});
		
		});